# 双击亮屏 / 抬腕亮屏 —— 修复包

- 机型：Xiaomi 15 `dada`（`24129PN74C`，sn `9dea5b0e`）
- 系统：Flyme 12.6.0.0A（SDK 36），**DSU 里测试**
- 日期：2026-10-11
- 全部结论均在真机上实测（证据见 `双击亮屏与抬腕亮屏-根因分析.md`）

---

## 一、一页速览：修好了什么

| 功能 | 状态 | 一句话 |
|---|---|---|
| **双击亮屏** | ✅ 真机已验证 | 桥下发 `ITouchFeature.setModeValue(0,14,1)`（驱动 feature = `Touch_Doubletap_Mode`），触摸 IC 才真正进入双击模式 |
| **抬腕亮屏（功能）** | ✅ 真机已验证 | 桥订阅 `xiaomi.sensor.pickup(33171036)`，熄屏收到 `1.0`（拿起）→ `PowerManager.wakeUp()` |
| **设置里的「抬腕亮屏」开关** | ✅ 已出现 | 两个常规入口被 `supportRaiseFlipFeature()` 挡住（读魅族私有传感器 65538/65539）；用覆盖把这两个资源指向 `proximity(8)` 即恢复 |
| **开关能控制功能** | ✅ 真机已验证 | 桥跟随 `mz_quick_wakeup_double_click` / `raisewakeup_switch` / `flipwakeup_switch`，与 Settings/SystemUI 同一套 key |
| 翻转亮屏 | ⚪ 未做（可选） | 本机没有 `flip_status`，只有 `screen_down(33171037)`，它**注册即上报 1.0**，映射给 Flyme 会被当成"翻到正面"而立即亮屏，危险 |

关键日志（正常状态应该是这样）：

```
MiGestureBridge: powerManager acquired (late)
MiGestureBridge: ready (doubleTap=true raise=true)
MiGestureBridge: pickup event value=1.0 screenOn=false power=true
MiGestureBridge: wakeUp(time,reason) ok                       ← 抬手亮屏
MiGestureBridge: pickup event value=2.0 screenOn=true  power=true   ← 放下时不重复唤醒
dmesg: [MI_TP_I][xiaomi_touch_set_mode_value:721]: Touch_Doubletap_Mode value [1]   ← 双击开关
```

---

## 二、四个根因（详细推导与实测见报告）

1. **双击亮屏**：Flyme 只写不存在的 `/sys/class/meizu/tp/gesture_control`，触摸 IC 从未进入双击模式。
   小米侧真正的开关是 `vendor.xiaomi.hw.touchfeature.ITouchFeature` 的 `setModeValue(0, 14, 1)`
   （驱动里 mode 14 = `Touch_Doubletap_Mode`），IC 进入 `DC_ENABLE_WAKEUP_GESTURE_MODE` 后双击会上报
   `KEY_WAKEUP(143)`，系统自行亮屏。
2. **抬腕亮屏**：Flyme 依赖魅族私有传感器 `config_flipSensorType=65538` / `config_raiseSensorType=65539`，
   本机不存在 → `MzUtils.supportRaiseFlipFeature()` 返回 false → 开关被移除、`RaiseFlipperController` 注册 null。
   而且小米 `pickup` 的语义（`1.0=拿起 / 2.0=放下`）与魅族（`2=拿起`）**相反**，所以不能直接复用 Flyme 的控制器。
3. **设置里看不到开关**：常规两个入口（`AODAndLockScreenSettings`、`FlymeRaiseFlipController`）都靠
   `supportRaiseFlipFeature()` 判定"硬件支持"，读的就是上面那两个资源 → 判定不支持 → 隐藏。
   （第三个 OR 条件查 FlymeLab 的 provider，本机没装 FlymeLab → false，不构成阻挡。）
   **独立页 `FlymeRaiseAndFlipFragment` 没有这个检测，一直可用。**
4. **开机后抬手失效**（做自启后才暴露）：KSU 的 `service.sh` 在 **uptime 5.6 秒**就起了桥，那时 `system_server`
   的 power 服务还没注册，`getSystemService(POWER_SERVICE)` 返回 **null 且不会自恢复**（异常被吞掉），
   而 `sensorservice`/`touchfeature` 是 init 起的 native 服务早已可用 → **pickup 事件收得到、却永远不唤醒**。
   假象：`screenOn=false` 是 `powerManager != null && isInteractive()` 算的，null 时永远为 false。

---

## 三、装法

### A. ROM 内置（正式推荐）

| 文件 | 放到 ROM 的哪里 |
|---|---|
| `成品/migesture.jar` | `/system/etc/migesture/migesture.jar` |
| `成品/migesture.rc` | `/system/etc/init/migesture.rc`（照抄 `/system/etc/init/mifod.rc` 的写法） |
| `成品/SensorTypesOverlay-signed.apk` | `product/overlay/`（与 `FrameworksResCommon_Mz.apk` 同目录）或 `vendor/overlay/` |

`migesture.rc` 要点：`service migesture /system/bin/app_process64 /system/bin MiGestureBridge`、
`class late_start`、`user root`、`seclabel u:r:su:s0`、`setenv CLASSPATH /system/etc/migesture/migesture.jar`、
`setenv ANDROID_ROOT /system`、`setenv ANDROID_DATA /data`。

> ⚠️ ROM 里用 init 起服务时，**不要**在 `on boot` 早期就起（同样会踩 power 服务竞态）；
> 用 `class late_start` 即可，桥内部还有 60 秒等待 + 兜底补取。

#### 关于 SensorTypesOverlay-signed.apk：改动内容与生效性，都实测过

反编译包内 APK，改动内容就是**两条**（再无其他）：

```
resource 0x7f010000 integer/config_flipSensorType   () 8
resource 0x7f010001 integer/config_raiseSensorType  () 8
manifest: package=com.flyme.overlay.sensortypes  targetPackage=android  isStatic=true  priority=601  hasCode=false
签名: CN=flyme-port（自签，SHA-256 b069601a75cbb64c6caf75f4955738b4cdd384087854ba9f678f0110839d8afe）
```

用**设备上的 `idmap2`**（OMS 用的同一套工具）生成映射，证明这两条确实绑到了 framework 的真实资源：

```
Mapping:
    0x010e01db -> 0x7f010000 (integer/config_flipSensorType -> integer/config_flipSensorType)
    0x010e01f3 -> 0x7f010001 (integer/config_raiseSensorType -> integer/config_raiseSensorType)
```

一个坑：这两个资源**不是 public overlayable**，`idmap2 create` **命令行默认会拒绝**
（`error: no resources were overlaid`）。但这**不影响装进 ROM**：设备上 OMS 自己给 `/product/overlay/`
的静态覆盖建 idmap 时不受此限 —— 证据是它给魅族那个生效中的包生成的
`/data/resource-cache/product@overlay@FrameworksResCommon_Mz.apk@idmap`，内容为 `Constraints: None`
+ 同样格式的映射（那个包用命令行生成**同样失败**，却照样生效）。

因此：

1. **首选**：直接把 `SensorTypesOverlay-signed.apk` 放进 ROM 的 `product/overlay/`。
2. **万一某次构建没自动生成 idmap**：把包内附带的 `product@overlay@SensorTypesOverlay.apk@idmap`
   放到 `/data/resource-cache/`（命名规则：APK 全路径把 `/` 换成 `@`，再加 `@idmap`）。
3. **签名**：魅族那个覆盖包与 framework-res 是**同一个签名**（`m9@meizu.com`）所以天然可信，我们的包是自签。
   若你的 ROM 对签名也卡，用平台签名给它重签即可。
4. 不愿动 ROM 时用下面的方式 C（root 运行时覆盖，已实测可用）。

### B. KernelSU 模块（不重打包，DSU 测试用）

```sh
adb push 成品/migesture-ksu.zip /data/local/tmp/
adb shell su -c 'ksud module install /data/local/tmp/migesture-ksu.zip'
# 重启 Flyme（DSU 的重启由你自己触发）
```

模块内容：`migesture.jar` + `service.sh`（等 `sys.boot_completed=1` 再起桥、supervisor 保活、可卸载）+ `module.prop`。

### C. 运行时覆盖：让设置里的开关出现（免重启，DSU 首选）

```sh
adb shell su -c 'sh 工具/apply_overlay.sh'
```

做的事：用 `cmd overlay fabricate` + `enable` 把 `android:integer/config_flipSensorType` 与
`config_raiseSensorType` 覆盖成 `8`（proximity，存在且对 Flyme 判断惰性），再 `am force-stop com.android.settings`
让设置重读资源。⚠️ **fabricated overlay 不跨重启**（实测：DSU 重启后两个资源又回到 `65538/65539`，设置里的抬腕开关随之消失）
—— 所以两个 KernelSU 模块的 `service.sh` 都会在**每次开机**自动重建一次（见"装法 B"），装任一模块即自愈；要永久生效就把 APK 放进 ROM。
撤销：`cmd overlay disable --user 0 com.android.shell:mzflip_test`（另一个同理）。

也可以直接打开独立页（不需要任何覆盖）：

```sh
adb shell su -c "am start -n 'com.android.settings/com.meizu.settings.MzSettingsActivity\$FlymeRaiseFlipSettingsActivity'"
```

---

## 四、验证

```sh
adb push 工具/verify_flyme.sh /data/local/tmp/
adb shell su -c 'sh /data/local/tmp/verify_flyme.sh'
```

要看的点：

| 检查 | 期望 |
|---|---|
| `cmd overlay lookup android android:integer/config_raiseSensorType` | `8` |
| `logcat -s MiGestureBridge:V` | `power=true` + `wakeUp(time,reason) ok` |
| `dmesg \| grep Touch_Doubletap_Mode` | 跟开关联动 `value [0]/[1]` |
| 设置 → 显示与亮度 / 息屏显示锁屏 / 独立页「抬腕亮屏」 | 开关可见 |
| 实测 | 熄屏双击亮屏、熄屏拿起亮屏；开关关掉后两者都失效 |

---

## 五、文件清单

```
双击亮屏与抬腕亮屏-总整理.md            一页汇总（现状 / 根因 / 时间线 / 用法 / 交付物 / 坑位 / 未做）
双击亮屏与抬腕亮屏-根因分析.md          主报告（8.1~8.9 全部实测证据、复现命令、结论清单）
修改清单.md                              每个成品改了什么 / SHA-256 / 怎么验的
成品/
  migesture-ksu.zip                     KernelSU 模块（桥 + 每次开机重建运行时覆盖）
  migesture.jar                         dex（ROM 内置 / 手动运行）
  migesture.rc                          ROM init 服务定义
  run_migesture.sh                      手动运行（调试用）
  SensorTypesOverlay-signed.apk         静态 RRO（放进 ROM 的 product/overlay，永久生效）
  product@overlay@SensorTypesOverlay.apk@idmap
                                        预生成 idmap（万一 ROM 不自动生成时放进 /data/resource-cache/）
  sensortypeoverlay-ksu.zip             KernelSU 模块：每次开机重建运行时覆盖（APK 也附在里面供打包 ROM）
  apply_overlay.sh                      当次开机生效的运行时覆盖（恢复设置里的开关）
源码/
  migesture/src/MiGestureBridge.java    桥源码（含注释说明每个坑）
  migesture/ksu/{module.prop,service.sh,uninstall.sh}
  migesture/README.md                   桥的说明：设置联动、开机竞态、编译方法
  sensortype-overlay/ksu/{module.prop,service.sh}
  sensortype-overlay/{AndroidManifest.xml,res/values/configs.xml,README.md,overlay.keystore}
工具/
  verify_flyme.sh                       一次性体检脚本
  start_raise.sh                        直接打开「抬腕亮屏」独立页
```

## 六、已知限制 / 注意

1. **静态 RRO 的 APK 到不了 `/product/overlay`**：那目录本身是 overlayfs 挂载点
   （`lowerdir=/mnt/vendor/mi_ext/product/overlay/:/product/overlay`，`/mnt/vendor/mi_ext` 是只读 erofs dm-7），
   KSU 模块挂进去的文件会被遮住 → 要永久生效就**进 ROM**（方式 A）。KSU 侧改用**运行时覆盖**：
   两个模块的 `service.sh` 每次开机重建（方式 B），或手动跑方式 C。
   ⚠️ `cmd overlay fabricate` 造出来的覆盖**不跨重启**（实测重启后 `lookup` 又回到 65538/65539），
   所以**不能只跑一次**——这正是"设置里的开关又不见了"的原因。
2. **别在 DSU 里自己 `adb reboot`**：会直接退出 DSU 回到主系统。重启交给使用者自己的 DSU 流程。
   KernelSU 模块装完先落在 `modules_update/`，下一次进 DSU 才生效。
3. `Resources.getSystem()` / `ActivityThread.systemMain().getSystemContext().getResources()` **不吃 overlay**
   （实测仍返回 65538/65539），只有应用取资源那条路（如 `pm.getResourcesForApplication("android")`）才生效 ——
   写探针自检时别用前者，否则会误判成"覆盖没生效"。
4. 编译环境：`javac -source 8 -target 8 -classpath <android-36/android.jar>` → `jar` → `d8 --min-api 34`；
   RRO 用 `aapt2 compile/link`（`-I` 要用**本机拉下来的** `framework-res.apk`）→ `zipalign` → `apksigner`。

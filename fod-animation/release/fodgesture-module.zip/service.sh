#!/system/bin/sh
# 开机启动 FOD 手势注入器
# 不再等 boot_completed +20s：注入器越早开始监听越好（logcat 未就绪时由看门狗重试），
# binder 在第一次触摸时才解析，所以开机极早期启动是安全的。
MODDIR=${0%/*}
D=/data/local/tmp/fodgesture
LOG=$D/watch.log
mkdir -p $D
cp -f $MODDIR/fodgesture.jar $D/fodgesture.jar || exit 1
chmod 644 $D/fodgesture.jar
export ANDROID_ROOT=/system
export ANDROID_DATA=/data
pkill -f 'fodgesture.FodGesture' 2>/dev/null
(
  echo "=== supervisor start $(date) (uptime $(cut -d' ' -f1 /proc/uptime)s) ===" >> $LOG
  while true; do
    CLASSPATH=$D/fodgesture.jar app_process /system/bin fodgesture.FodGesture logwatch >> $LOG 2>&1
    echo "=== daemon exited $(date), restart in 2s ===" >> $LOG
    sleep 2
  done
) &

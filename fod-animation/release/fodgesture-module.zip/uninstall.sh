#!/system/bin/sh
pkill -f 'fodgesture.FodGesture' 2>/dev/null
rm -rf /data/local/tmp/fodgesture
